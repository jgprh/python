from .main import EAGM
__version__      = '1.2.0'
__url__          = 'https://github.com/taka-4602/Discord-Easy-Add-Guild-Member'